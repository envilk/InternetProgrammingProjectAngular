angular.module('chollosApp')
.controller('listCtrl', ['chollosFactory',function(chollosFactory){
    var listViewModel = this;
    listViewModel.chollos=[];
    listViewModel.functions = {
    	readChollos : function() {
    		chollosFactory.getChollos()
				.then(function(response){
	    			console.log("Reading all the chollos:--------------------------------------- ", response);
	    			listViewModel.chollos = response;
	    		}, function(response){
	    			console.log("Error reading chollos----------------------------------------------");
	    		})
		}
    }
    listViewModel.functions.readChollos();
}])