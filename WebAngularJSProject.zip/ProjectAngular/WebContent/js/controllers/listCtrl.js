angular.module('pizzeriaApp')
.controller('listCtrl', ['ordersFactory',function(ordersFactory){
    var listViewModel = this;
    listViewModel.orders=[];
    listViewModel.functions = {
    	readOrders : function() {
    		ordersFactory.getOrders()
				.then(function(response){
	    			console.log("Reading all the orders: ", response);
	    			listViewModel.orders = response;
	    		}, function(response){
	    			console.log("Error reading orders");
	    		})
		}
    }
    listViewModel.functions.readOrders();
}])