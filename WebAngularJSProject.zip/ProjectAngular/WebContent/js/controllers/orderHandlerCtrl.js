angular.module('pizzeriaApp')
.controller('orderHandlerCtrl', ['ordersFactory','usersFactory','$routeParams','$location',
			function(ordersFactory,usersFactory,$routeParams,$location){
	var orderHandlerViewModel = this;
    orderHandlerViewModel.order={};
   	orderHandlerViewModel.functions = {
   		where : function(route){
   			return $location.path() == route;
   		},
		readUserNameEmail : function() {
			usersFactory.getUser()
				.then(function(response){
					orderHandlerViewModel.order.name= response.name;
					orderHandlerViewModel.order.email= response.email;
					console.log("Reading user with id: ",response.id," Response: ", response);
    			}, function(response){
    				console.log("Error reading user data");
    			})
		},
		readOrder : function(id) {
			ordersFactory.getOrder(id)
				.then(function(response){
					console.log("Reading order with id: ", id," Response: ", response);
					orderHandlerViewModel.order = response;
				}, function(response){
					console.log("Error reading order");
					$location.path('/');
				})
		},
		updateOrder : function() {
			ordersFactory.putOrder(orderHandlerViewModel.order)
				.then(function(response){
					console.log("Updating order with id:",orderHandlerViewModel.order.id," Response:", response);
    			}, function(response){
    				console.log("Error updating order");
    			})
		},	
		createOrder : function() {
	        ordersFactory.postOrder(orderHandlerViewModel.order)
				.then(function(response){
					console.log("Creating order. Response:", response);
    			}, function(response){
    				console.log("Error creating the order");
    			})
		},
		deleteOrder : function(id) {
			ordersFactory.deleteOrder(id)
				.then(function(response){
					console.log("Deleting order with id:",id," Response:", response);
				}, function(response){
					console.log("Error deleting order");
				})
		},
		orderHandlerSwitcher : function(){
			if (orderHandlerViewModel.functions.where('/insertOrder')){
				console.log($location.path());
				orderHandlerViewModel.functions.createOrder();
			}
			else if (orderHandlerViewModel.functions.where('/editOrder/'+orderHandlerViewModel.order.id)){
				console.log($location.path());
				orderHandlerViewModel.functions.updateOrder();
			}
			else if (orderHandlerViewModel.functions.where('/deleteOrder/'+orderHandlerViewModel.order.id)){
				console.log($location.path());
				orderHandlerViewModel.functions.deleteOrder(orderHandlerViewModel.order.id);
			}
			else {
			console.log($location.path());
			}
			$location.path('/');
		}
	}
   	console.log("Entering orderHandlerCtrl with $routeParams.ID=",$routeParams.ID);
   	if ($routeParams.ID==undefined) orderHandlerViewModel.functions.readUserNameEmail();
   	else orderHandlerViewModel.functions.readOrder($routeParams.ID);
}]);