angular.module('chollosApp')
.controller('listCtrl', ['chollosFactory','likesFactory','$location',function(chollosFactory, likesFactory, $location){
	var listViewModel = this;
	listViewModel.chollos=[];
	listViewModel.cholloId={};
	listViewModel.functions = {
			where : function(route){
				return $location.path() == route;
			},
			readChollos : function() {
				chollosFactory.getChollos()
				.then(function(response){
					console.log("Reading all the chollos:--------------------------------------- ", response);
					listViewModel.chollos = response;
				}, function(response){
					console.log("Error reading chollos----------------------------------------------");
				})
			},
			createLike : function(cholloId) {
				console.log(cholloId)
				likesFactory.postLike(cholloId)
				.then(function(response){
					console.log("Liked chollo: "+cholloId);
				}, function(response){
					console.log("Error in likes");
				})
			}
	}
	var str = $location.path();
	if (str.includes("/likes/")){
		var array = str.split("/");
		console.log(array[2])
		listViewModel.functions.createLike(array[2]);
		$location.path('/');
	}
	listViewModel.functions.readChollos();
}])