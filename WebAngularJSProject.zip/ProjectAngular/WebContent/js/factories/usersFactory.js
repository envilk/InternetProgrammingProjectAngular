angular.module('chollosApp')
.factory('usersFactory',['$http', function($http){
	var url = 'https://localhost:8443/ProjectAngular/rest/users/';
    var usersInterface = {
    	getUser : function(){
    		url = url ;
            return $http.get(url)
              	.then(function(response){
        			 return response.data;
               	});
    	}			
    }
    return usersInterface;
}])