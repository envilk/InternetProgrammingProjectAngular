angular.module('chollosApp')
.controller('likesCtrl', ['chollosFactory','usersFactory',function(chollosFactory,usersFactory){
    var likesViewModel = this;
    likesViewModel.chollos=[];
    likesViewModel.functions = {
    	readChollos : function() {
    		chollosFactory.getChollos()
				.then(function(response){
	    			console.log("");
	    			likesViewModel.chollos = response;
	    		}, function(response){
	    			console.log("Error en likes");
	    		})
		}
    }
    listViewModel.functions.readChollos();
}])