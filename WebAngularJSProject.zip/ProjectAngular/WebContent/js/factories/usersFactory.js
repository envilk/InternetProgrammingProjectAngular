angular.module('pizzeriaApp')
.factory('usersFactory',['$http', function($http){
	var url = 'https://localhost:8443/sl09_inlab_E1/rest/users/';
    var usersInterface = {
    	getUser : function(){
    		url = url ;
            return $http.get(url)
              	.then(function(response){
        			 return response.data;
               	});
    	}			
    }
    return usersInterface;
}])